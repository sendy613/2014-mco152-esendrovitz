package sendrovitz.minesweeper;

public class NotFoundException extends Exception {

}
