package sendrovitz.opportunity;

public class Ncam_Images {
	private Images images[];

	public Images[] getImages() {
		return images;
	}

	public void setImages(Images[] images) {
		this.images = images;
	}
}
