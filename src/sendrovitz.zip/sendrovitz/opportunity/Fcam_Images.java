package sendrovitz.opportunity;

public class Fcam_Images {
	private Images images[];

	public Images[] getImages() {
		return images;
	}

	public void setImages(Images[] images) {
		this.images = images;
	}
}
