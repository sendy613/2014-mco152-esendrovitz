package sendrovitz.opportunity;

public class Instance {
	private Mi_Images mi_images[];
	private Pcam_Images pcam_images[];
	private Ncam_Images ncam_images[];
	private Fcam_Images fcam_images[];

	public Mi_Images[] getMi_images() {
		return mi_images;
	}

	public void setMi_images(Mi_Images[] mi_images) {
		this.mi_images = mi_images;
	}

	public Pcam_Images[] getPcam_images() {
		return pcam_images;
	}

	public void setPcam_images(Pcam_Images[] pcam_images) {
		this.pcam_images = pcam_images;
	}

	public Ncam_Images[] getNcam_images() {
		return ncam_images;
	}

	public void setNcam_images(Ncam_Images[] ncam_images) {
		this.ncam_images = ncam_images;
	}

	public Fcam_Images[] getFcam_images() {
		return fcam_images;
	}

	public void setFcam_images(Fcam_Images[] fcam_images) {
		this.fcam_images = fcam_images;
	}

}
