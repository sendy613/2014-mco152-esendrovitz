package sendrovitz.opportunity;

public class Pcam_Images {
	private Images images[];

	public Images[] getImages() {
		return images;
	}

	public void setImages(Images[] images) {
		this.images = images;
	}
}
