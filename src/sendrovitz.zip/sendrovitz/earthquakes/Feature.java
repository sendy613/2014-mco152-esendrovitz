package sendrovitz.earthquakes;

public class Feature {
private Properties properties;

public Properties getProperties() {
	return properties;
}
}
