package sendrovitz.earthquakes;

public class Properties {
private Double mag;
private String place;

public Double getMag() {
	return mag;
}
public String getPlace() {
	return place;
}
}
