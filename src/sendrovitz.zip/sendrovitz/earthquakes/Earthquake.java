package sendrovitz.earthquakes;

public class Earthquake {
	private Feature[] features;
public Feature[] getFeatures() {
		return features;
	}


}
