package sendrovitz.iss;

public class Response {
private Long risetime;

public Long getRisetime() {
	return risetime;
}
}
