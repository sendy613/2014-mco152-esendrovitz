package sendrovitz.iss;

public class Instance2 {
private Response[] response;

public Response[] getResponse() {
	return response;
}
}
