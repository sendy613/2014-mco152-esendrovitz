package sendrovitz.iss;

public class Instance {
private Results[] results;

public Results[] getResults() {
	return results;
}

}
