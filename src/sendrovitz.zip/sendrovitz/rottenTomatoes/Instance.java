package sendrovitz.rottenTomatoes;

public class Instance {
private Movies[] movies;

public Movies[] getMovies() {
	return movies;
}

public void setMovies(Movies[] movies) {
	this.movies = movies;
}
}
