package sendrovitz.rottenTomatoes;

public class Posters {
private String thumbnail;

public String getThumbnail() {
	return thumbnail;
}

public void setThumbnail(String thumbnail) {
	this.thumbnail = thumbnail;
}
}
