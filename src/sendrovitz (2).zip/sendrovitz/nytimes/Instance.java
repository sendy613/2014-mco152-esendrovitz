package sendrovitz.nytimes;

public class Instance {
private Response response;

public Response getResponse() {
	return response;
}
}
